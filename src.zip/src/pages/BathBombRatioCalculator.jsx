import { useState, useEffect } from "react";
function BathBombRatioCalculator() {
  const [bombs, setBombs] = useState(4);
  const [size, setSize] = useState(150);
  const [oilPercent, setOilPercent] = useState(1.5);
  const [customSoda, setCustomSoda] = useState("");
  const totalWeight = bombs * size;
  const dryBase = totalWeight * (1 - oilPercent / 100);
  const bakingSoda = dryBase * 0.51;
  const citricAcid = dryBase * 0.255;
  const epsomSalt = dryBase * 0.10;
  const cornStarch = dryBase * 0.10;
  const coconutOil = dryBase * 0.025;
  const witchHazel = dryBase * 0.01;
  const essentialOil = totalWeight * (oilPercent / 100);
  useEffect(()=>{document.title="Bath Bomb Ratio Calculator UK & USA | Recipe in Grams | Caltrixaa";},[]);
  const customCitric = customSoda? Number(customSoda)/2 : 0;
  return (
    <div className="min-h-screen bg-white">
      <script type="application/ld+json" dangerouslySetInnerHTML={{__html: JSON.stringify({"@context":"https://schema.org","@type":"FAQPage","mainEntity":[{"@type":"Question","name":"What is the 1:2 bath bomb ratio calculator?","acceptedAnswer":{"@type":"Answer","text":"2 parts baking soda to 1 part citric acid. Our bath bomb ratio calculator uses 51% soda and 25.5% acid for UK & USA grams."}},{"@type":"Question","name":"Bath bomb recipe calculator UK grams how much baking soda?","acceptedAnswer":{"@type":"Answer","text":"For 150g bomb, 76.5g baking soda. For 4 bombs 600g, 301.4g baking soda. Use editable bath bomb ingredients calculator to type your own."}}]})}} />
      <div className="bg-slate-50 py-10 px-4 border-b">
        <div className="mx-auto max-w-5xl">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold">Bath Bomb Ratio Calculator - Perfect 1:2 Recipe in Grams (UK & USA)</h1>
            <p className="mt-3 text-slate-600">Free bath bomb ingredients calculator. Editable: type your own bombs, grams, and check ratio. UK grams & USA ounces.</p>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="rounded-3xl bg-white p-6 shadow-sm border">
              <h3 className="font-bold text-lg mb-5">Your Batch - Type Your Own</h3>
              <label className="text-sm font-semibold">How Many Bath Bombs? (Type)</label>
              <input type="number" min="1" max="1000" value={bombs} onChange={e=>setBombs(Number(e.target.value)||1)} className="w-full mt-2 rounded-xl border-2 border-indigo-200 p-3 font-bold text-lg focus:border-indigo-600 outline-none" />
              <input type="range" min="1" max="50" value={bombs} onChange={e=>setBombs(+e.target.value)} className="w-full accent-indigo-600 my-3" />
              <label className="text-sm font-semibold mt-4 block">Size Per Bomb in Grams (Type Any)</label>
              <input type="number" value={size} onChange={e=>setSize(Number(e.target.value)||100)} className="w-full mt-2 rounded-xl border-2 border-indigo-200 p-3 font-bold text-lg focus:border-indigo-600 outline-none" />
              <div className="grid grid-cols-4 gap-2 mt-3">
                {[100,150,200,250].map(v=>(<button key={v} onClick={()=>setSize(v)} className={`py-2 rounded-xl text-xs font-bold border-2 ${size===v?'bg-slate-900 text-white border-slate-900':'bg-white'}`}>{v}g</button>))}
              </div>
              <div className="mt-6 rounded-2xl bg-slate-900 text-white p-5 text-center"><p className="text-xs opacity-70 uppercase">Total Batch Weight</p><p className="text-3xl font-bold mt-1">{totalWeight} g / {(totalWeight/28.35).toFixed(1)} oz</p></div>
              <div className="mt-6 p-4 rounded-2xl bg-amber-50 border-2 border-amber-200">
                <h4 className="font-bold text-sm text-amber-900">✅ Check Your Own Recipe Ratio</h4>
                <input type="number" value={customSoda} onChange={e=>setCustomSoda(e.target.value)} placeholder="Your Baking Soda e.g. 300" className="w-full mt-3 rounded-xl border-2 border-amber-200 p-3 font-bold outline-none" />
                {customSoda && (<div className="mt-3 bg-white rounded-xl p-3 border text-sm"><p>For <b>{customSoda}g</b> Soda, you need:</p><p>👉 Citric: <b className="text-pink-600">{customCitric.toFixed(1)}g</b> (1:2 Ratio)</p><p>👉 Total: ~{(Number(customSoda)+customCitric).toFixed(0)}g</p></div>)}
              </div>
            </div>
            <div className="rounded-3xl bg-white p-6 shadow-sm border">
              <h3 className="font-bold text-lg mb-5">Recipe Ingredients (Grams & Oz)</h3>
              <div className="space-y-3">
                <Row name="Baking Soda" sub="51% - UK/USA standard" val={bakingSoda} />
                <Row name="Citric Acid" sub="25.5% - 1:2 ratio" val={citricAcid} />
                <Row name="Epsom Salt" sub="10%" val={epsomSalt} />
                <Row name="Cornstarch" sub="10%" val={cornStarch} />
                <Row name="Coconut Oil" sub="2.5%" val={coconutOil} />
                <Row name="Essential Oil" sub={`${oilPercent}%`} val={essentialOil} highlight />
                <Row name="Witch Hazel" sub="1%" val={witchHazel} />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="mx-auto max-w-4xl px-4 py-12">
        <h2 className="text-2xl font-bold">Bath Bomb Recipe Calculator UK Grams - Perfect 1:2 Ratio</h2>
        <p className="text-slate-600 leading-7 mt-3">This <strong>bath bomb ratio calculator</strong> is for UK & USA. The perfect <strong>bath bomb ratio</strong> is 2 parts baking soda to 1 part citric acid. If you search <strong>how much baking soda for bath bomb</strong>, <strong>bath bomb recipe calculator uk grams</strong>, or <strong>bath bomb ingredients calculator</strong>, this editable calculator gives exact grams & ounces. For 4 bombs (600g total) you need 301.4g baking soda.</p>
        <p className="text-xs text-slate-400 mt-8">Keywords included: bath bomb ratio calculator, bath bomb ratio calculator uk, bath bomb recipe calculator uk grams, bath bomb ingredients calculator, how much baking soda for bath bomb calculator, 1:2 bath bomb ratio calculator, bath bomb calculator grams, bath bomb recipe calculator uk.</p>
      </div>
    </div>
  );
}
function Row({name, sub, val, highlight}){return(<div className={`flex justify-between items-center rounded-xl px-4 py-3 border ${highlight?'bg-pink-50 border-pink-200':'bg-slate-50'}`}><div><p className="text-sm font-semibold">{name}</p><p className="text-[11px] text-slate-500">{sub}</p></div><span className="font-bold text-right"><span className="block">{val.toFixed(1)} g</span><span className="block text-[11px] font-normal opacity-60">{(val/28.35).toFixed(2)} oz</span></span></div>)}
export default BathBombRatioCalculator;